const greeting: string = "Hello World"
console.log(gre);
