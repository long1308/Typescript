const greeting: string = "Hello World"
console.log(greeting);
let a: number =
