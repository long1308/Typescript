const greeting: string = "Hello World"
// console.log(greeting);
let a: number = 4;
a = 5;
console.log(a greeting);

